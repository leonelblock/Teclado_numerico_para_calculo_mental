#include <Keyboard.h>
int last_key_pressed;

void setup() {

  pinMode(0, INPUT_PULLUP);
  pinMode(1, INPUT_PULLUP);
  pinMode(2, INPUT_PULLUP);
  pinMode(3, INPUT_PULLUP);
  pinMode(4, INPUT_PULLUP);
  pinMode(5, INPUT_PULLUP);
  pinMode(6, INPUT_PULLUP);
  pinMode(7, INPUT_PULLUP);
  pinMode(8, INPUT_PULLUP);
  pinMode(9, INPUT_PULLUP);
  pinMode(10, INPUT_PULLUP);
  pinMode(11, INPUT_PULLUP);
  // macro activar si se quiere pinMode(12, INPUT_PULLUP);
  Keyboard.begin();
  Serial.begin(9600);
  last_key_pressed = 99;
}


void loop() {
  delay(1);

  if (digitalRead(0) == LOW) {
    Keyboard.press('0');
    last_key_pressed = 0;
  } 
  else if (last_key_pressed==0) {
    Keyboard.release('0');
    last_key_pressed = 99;
  }
  
  if (digitalRead(1) == LOW) {
    Keyboard.press('1');
    last_key_pressed = 1;
  } 
  else if (last_key_pressed==1) {
    Keyboard.release('1');
    last_key_pressed = 99;
  }

  if (digitalRead(2) == LOW) {
    Keyboard.press('2');
    last_key_pressed = 2;
  } 
  else if (last_key_pressed==2) {
    Keyboard.release('2');
    last_key_pressed = 99;
  }

  if (digitalRead(3) == LOW) {
    Keyboard.press('3');
    last_key_pressed = 3;
  } 
  else if (last_key_pressed==3) {
    Keyboard.release('3');
    last_key_pressed = 99;
  }

  if (digitalRead(4) == LOW) {
    Keyboard.press('4');
    last_key_pressed = 4;
  } 
  else if (last_key_pressed==4) {
    Keyboard.release('4');
    last_key_pressed = 99;
  }
  if (digitalRead(5) == LOW) {
    Keyboard.press('5');
    last_key_pressed = 5;
  } 

  else if (last_key_pressed==5) {
    Keyboard.release('5');
    last_key_pressed = 99;
  }

  if (digitalRead(6) == LOW) {
    Keyboard.press('6');
    last_key_pressed = 6;
  } 

  else if (last_key_pressed==6) {
    Keyboard.release('6');
    last_key_pressed = 99;
  }

  if (digitalRead(7) == LOW) {
    Keyboard.press('7');
    last_key_pressed = 7;
  } 

  else if (last_key_pressed==7) {
    Keyboard.release('7');
    last_key_pressed = 99;
  }

  if (digitalRead(8) == LOW) {
    Keyboard.press('8');
    last_key_pressed = 8;
  } 

  else if (last_key_pressed==8) {
  Keyboard.release('8');
  last_key_pressed = 99;
  }

  if (digitalRead(9) == LOW) {
    Keyboard.press('9');
    last_key_pressed = 9;
  } 

  else if (last_key_pressed==9) {
     Keyboard.release('9');
    last_key_pressed = 99;
  }

  if (digitalRead(10) == LOW) {
    Keyboard.press(KEY_BACKSPACE);
    last_key_pressed = 10;
  } 

  else if (last_key_pressed==10) {
    Keyboard.release(KEY_BACKSPACE);
    last_key_pressed = 99;
  }

  if (digitalRead(11) == LOW) {
    Keyboard.press(KEY_RETURN);
    last_key_pressed = 11;
  } 

  else if (last_key_pressed==11) {
   Keyboard.release(KEY_RETURN);
    last_key_pressed = 99;
  }
}