#include <BleKeyboard.h>

// Nombre del teclado, fabricante y nivel de batería inicial
BleKeyboard Keyboard("Tecladofeo", "tapabanos", 100);

int lastkeypressed = 1000;

void setup() {
  pinMode(14, INPUT_PULLUP);
  pinMode(15, INPUT_PULLUP);
  pinMode(16, INPUT_PULLUP);
  pinMode(17, INPUT_PULLUP);
  pinMode(18, INPUT_PULLUP);
  pinMode(19, INPUT_PULLUP);
  pinMode(21, INPUT_PULLUP);
  pinMode(22, INPUT_PULLUP);
  pinMode(23, INPUT_PULLUP);
  pinMode(25, INPUT_PULLUP);
  pinMode(26, INPUT_PULLUP);
  pinMode(27, INPUT_PULLUP);

  // macro activar si se quiere pinMode(28, INPUT_PULLUP);
  Keyboard.begin();
  delay(4000);
}

void loop() {
  delay(10);

  if (Keyboard.isConnected()) {

    if (digitalRead(14) == LOW) {
      Keyboard.press('0');
    } else {
      Keyboard.release('0');
    }

    if (digitalRead(15) == LOW) {
      Keyboard.press('1');
    } else {
      Keyboard.release('1');
    }

    if (digitalRead(16) == LOW) {
      Keyboard.press('2');
    } else {
      Keyboard.release('2');
    }

    if (digitalRead(17) == LOW) {
      Keyboard.press('3');
    } else {
      Keyboard.release('3');
    }

    if (digitalRead(18) == LOW) {
      Keyboard.press('4');
    } else {
      Keyboard.release('4');
    }

    if (digitalRead(19) == LOW) {
      Keyboard.press('5');
    } else {
      Keyboard.release('5');
    }

    if (digitalRead(21) == LOW) {
      Keyboard.press('6');
    } else {
      Keyboard.release('6');
    }

    if (digitalRead(22) == LOW) {
      Keyboard.press('7');
    } else {
      Keyboard.release('7');
    }

    if (digitalRead(23) == LOW) {
      Keyboard.press('8');
    } else {
      Keyboard.release('8');
    }

    if (digitalRead(25) == LOW) {
      Keyboard.press('9');
    } else {
      Keyboard.release('9');
    }

    if (digitalRead(26) == LOW) {
      Keyboard.press(KEY_BACKSPACE);
    } else {
      Keyboard.release(KEY_BACKSPACE);
    }

    if (digitalRead(27) == LOW) {
      Keyboard.press(KEY_RETURN);
    } else {
      Keyboard.release(KEY_RETURN);
    }

  }
}